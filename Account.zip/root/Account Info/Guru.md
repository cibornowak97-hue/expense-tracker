# Guru
Milos Milic:  
magneticraider@gmail.com / MilosM\*12345  
Milos guru:  
magneticraider@gmail.com  
password: Novikolac456@  
question: barcelona1,2,3

  
Marko Guru  
markojovfreelancer@gmail.com / Marko\*2023\*39#  
barcelonaschool  
barcelonateacher  
barcelonawith