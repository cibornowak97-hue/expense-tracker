# Fairy
AI Automation | Agents & Full Stack Web Development

Astrill

stojkemilos999@gmail.com

gmail

roblonicolalouise160@gmail.com/valid1181 +63 961 094 9964

nicolalouise781@gmail.com/breakout\_211

[cibornowak97@gmail.com/Cibor\*nowak122/cibornowak@hotmail.com](cibornowak97@gmail.com)

devnexa30@gmail.com / University12345\*

sheet

https://docs.google.com/spreadsheets/d/1a6RtSbzTML97RvVibPcFRzNQYhrxkZlGWKLoXyQkezA/edit?pli=1&gid=834111036#gid=834111036

New Octo browser info  
markojovfreelancer@gmail.com  
2CBtk6WZ

Telegram:

CTNsoft

381 62 868 2019

bep20: 0x9d31219e24f642f58d77adf85685cdc2369eac88

https://taomarketcap.com

<span class="link-mention" data-url="https://forms.gle/7nwKSKdCs6NqMV8g7" data-embed-type="opengraph" data-title="LBLX128 | Senior Python Developers - AI Model Reviewer " data-description="Thank you for your interest in this project! As mentioned in the job post, you will need to answer the screening questions below in order for your proposal to be considered." data-favicon="Fairy_forms.gle.png" data-site-name="Google Docs" data-image="Fairy_forms.gle-7nwKSKdCs6NqMV8g7-2d541bcd.jpeg"><a href="https://forms.gle/7nwKSKdCs6NqMV8g7">LBLX128 | Senior Python Developers - AI Model Reviewer</a></span>

https://www.craigslist.org

data annotation url

https://docs.google.com/forms/d/e/1FAIpQLSddOA6YHXnUb2Xhbrf4sINRCLajQR1NcI1XXzuhKQj69rxFdA/viewform?usp=header

  
https://www.dataannotation.tech/coding?projects=PROG\_SA&worker\_src=UW&utm\_source=upwork&utm\_medium=referral&utm\_campaign=coder&utm\_adgroup=ai\_trainer

basic details

First Name  
Middle Name  
Last Name  
  
Age  
  
Full address  
House/blk & Lot  
Street  
Municipality/city  
State/province  
Country  
Zip code