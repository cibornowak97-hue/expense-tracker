# US
We can collaborate

Hi there!  
How is it going?  
I’m a senior AI engineer from Serbia, and I’m looking for someone from the United States who would be interested in collaborating with me.

I’m planning to work on some AI training platforms, but unfortunately, some of these platforms only accept engineers from certain countries, such as the US, UK, and others. Because Serbia is not supported on some of them, I can’t work on these opportunities directly.

That’s why I’m looking for a US-based collaborator. If we can work together on these platforms, I believe I can make more than $10,000 per month, and I would be happy to share the earnings with you.

Software development and AI engineering are my strong side, so I would handle the technical work and everything related to development.

If you are interested in this kind of collaboration, please feel free to DM me here:

Telegram: @ctn\_soft  
Gmail: nicolalouise781@gmail.com

Thanks and I hope to hear from you!