# Communication Agent
I can get 5K at least per month if I can get task from Upwork.  I'm very strong on the technical side - full-stack development, automation, AI systems, mobile apps - but sometimes I get stuck with getting job and communication, and that slows me down with clients.  
That's why I'm looking for someone who can handle client interaction, communication, while I focus on delivering all the technical work.  
If you have experience with platforms like Upwork or Freelancer, or you are based in the Europe, that's a bonus - clients from those regions usually expect stronger communication and trust people from their own region more.  
We can work together as a team, win projects together, and share the income fairly depending on our contributions.  
I'm hardworking, loyal, and committed - you won't need to worry about the technical stack, I can build everything end to end.