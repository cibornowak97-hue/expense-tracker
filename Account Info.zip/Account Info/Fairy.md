# Fairy
AI Automation | Agents & Full Stack Web Development

Astrill

stojkemilos999@gmail.com

gmail

nicolalouise3108@gmail.com/field1181

[cibornowak97@gmail.com/Cibor\*nowak122/cibornowak@hotmail.com](cibornowak97@gmail.com)

devnexa30@gmail.com / University12345\*

sheet

https://docs.google.com/spreadsheets/d/1a6RtSbzTML97RvVibPcFRzNQYhrxkZlGWKLoXyQkezA/edit?pli=1&gid=834111036#gid=834111036

Telegram:

CTNsoft

381 62 868 2019

bep20: 0x9d31219e24f642f58d77adf85685cdc2369eac88

https://taomarketcap.com/

basic details

First Name  
Middle Name  
Last Name  
  
Age  
  
Full address  
House/blk & Lot  
Street  
Municipality/city  
State/province  
Country  
Zip code